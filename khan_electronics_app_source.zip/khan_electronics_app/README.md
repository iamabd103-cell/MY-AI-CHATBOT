# Khan Electronics App (PWA starter)

A mobile-first installable web app for Khan Electronics, built with React and Vite. It can be used in a mobile browser and can be installed to a compatible device's home screen when served over HTTPS.

## Run locally
Requires Node.js 18+ and npm.

```bash
npm install
npm run dev
```

Create a production build with `npm run build`, then deploy the generated `dist/` folder to an HTTPS static host.

## Included
- Mobile-first app interface with bottom navigation
- Home, categories, search, product filters and sorting
- Product details, wishlist toggle, quantity picker
- Shopping bag and checkout flow
- Cash on delivery option and online-payment placeholder
- Order history stored in the current browser
- Demo store admin: create/edit/delete products and export catalogue
- Browser storage persistence and basic PWA manifest/service worker

## Production checklist
This is a front-end starter, not a secure live commerce backend. Before real orders:
- Connect an API/database for products, customers, stock and orders.
- Add real admin authentication and server-side authorization.
- Integrate Stripe/PayPal or another provider with server-side session creation and verified webhooks. The current online payment option is demo-only and charges nothing.
- Validate totals, stock and delivery on the server. Never trust browser values as the final price.
- Configure HTTPS, privacy/cookie policy, terms, returns/refunds and contact information.
- Add push notifications/order tracking only after connecting a backend.
- Test on real Android and iOS devices; PWA installation varies by browser/platform.
- Replace sample products and verify image licenses and URLs.
